package com.book.service;

	import java.util.List;

	import com.book.dao.BookDao;
	import com.book.model.Book;
import com.book.model.DatabaseDetails;
import com.book.validation.InvalidException;

	@SuppressWarnings("unused")
	public class BookService
	{
		
		public  String createDetails(Book obj) 
		{
			
			BookDao j1=new BookDao();
			
			return j1.createDetails(obj);
		}
		public List<Book> getBook() 
		{
			BookDao j2=new BookDao();
			return j2.getBook();
		}
		public String updateRecord(Book obj)
		{
			BookDao j3=new BookDao();
			return j3.updateRecord(obj);
		}
		public void deleteBid(int id)
		{
			BookDao j4=new BookDao();
			 j4.deleteBid(id);
		}
		public String getRecordById(Book obj)
		{
			BookDao j5=new BookDao();
			return j5.getRecordById(obj);
		}
		public Book getRecordById(int id, DatabaseDetails gt) {
			
			return null;
		}
	}

