package com.book.service;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


import com.book.dao.BookDao;
import com.book.model.Book;
import com.book.service.BookService;


@WebServlet("/getbyidservlet")
public class getbyidservlet extends HttpServlet {
	@Override
	protected void service(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException 
{
		
		
		int id=Integer.parseInt(req.getParameter("b_id"));
		String name=req.getParameter("b_name");
		int price=Integer.parseInt(req.getParameter("b_price"));
	    Book obj=new Book();
		
		
		obj.setB_id(id);
		obj.setB_name(name);
		obj.setB_price(price);
		BookService obj2=new BookService();
		String r=obj2.getRecordById(obj);
		req.setAttribute("byid", r);
		req.setAttribute("p1", obj);
		
		req.getRequestDispatcher("getbyidResponse.jsp").forward(req, resp);

		

}
}