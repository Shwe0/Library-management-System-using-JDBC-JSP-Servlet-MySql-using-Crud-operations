package com.book.validation;

public class InvalidException {

}
