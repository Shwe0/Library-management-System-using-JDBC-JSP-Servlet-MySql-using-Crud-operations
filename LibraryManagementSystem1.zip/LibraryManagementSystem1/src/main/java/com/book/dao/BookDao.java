package com.book.dao;

	import java.sql.Connection;
	import java.sql.DriverManager;
	import java.sql.PreparedStatement;
	import java.sql.ResultSet;
	import java.sql.SQLException;
	import java.util.ArrayList;
	import java.util.List;

	import com.book.model.Book;
	import com.book.validation.InvalidException;

	public class BookDao {
		String username="root";
		String pwd="Root123";
		String url="jdbc:mysql://localhost:3306/librarymanagement";
		String insertq="insert into book2(b_id,b_name,b_price)values(?,?,?)";
		String readq="select *from book2";
		String updateq="update book2 set b_name=?,b_price=? where b_id=?";
		String deleteq="Delete from book2 where b_id=?";
		String byid="select *from book2 where b_id=?";
		public String createDetails(Book obj)
		{
			
			
			try {
				Class.forName("com.mysql.cj.jdbc.Driver");
				
			} catch (ClassNotFoundException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			try {
				Connection co=DriverManager.getConnection(url,username,pwd);
				PreparedStatement pr=co.prepareStatement(insertq);
				pr.setInt(1, obj.getB_id());
				pr.setString(2, obj.getB_name());
				pr.setInt(3, obj.getB_price());
				int result=pr.executeUpdate();
				if(result>0)
				{
					return "success";
					
				}
				co.close();
				pr.close();
			}catch(SQLException e) {
				e.printStackTrace();
			}
			return "failed";
				
			
		}

		public List<Book> getBook() {
			List<Book> e1=new ArrayList<Book>();
			try {
				Class.forName("com.mysql.cj.jdbc.Driver");
			}catch(ClassNotFoundException e)
			{
				e.printStackTrace();
			}
			try {
				Connection co=DriverManager.getConnection(url,username,pwd);
				PreparedStatement pr=co.prepareStatement(readq);
				ResultSet r1=pr.executeQuery();
				while(r1.next())
				{
					int id=r1.getInt("b_id");
					String name=r1.getString("b_name");
					int price=r1.getInt("b_price");
					
					Book emp1=new Book(id,name,price);
					e1.add(emp1);
				}
				co.close();
				pr.close();
			}catch(SQLException e) {
				e.printStackTrace();
			}
			return e1;
			
		}

		public String updateRecord(Book obj) {
			
			try {
				Class.forName("com.mysql.cj.jdbc.Driver");
			}catch(ClassNotFoundException e)
			{
				e.printStackTrace();
			}
			try {
				Connection co=DriverManager.getConnection(url,username,pwd);
				PreparedStatement pr=co.prepareStatement(updateq);
				
			
				
				pr.setInt(1, obj.getB_id());
				pr.setString(2,obj.getB_name());
				pr.setInt(3, obj.getB_price());
				int result=pr.executeUpdate();
				if(result>0)
				{
					return "success";	
				}
				co.close();
				pr.close();
			}catch(SQLException e) {
				e.printStackTrace();
			}
			return "failed";
			
			
		}

		public void deleteBid(int id) {
			try {
				Class.forName("com.mysql.cj.jdbc.Driver");
			}catch(ClassNotFoundException e)
			{
				e.printStackTrace();
			}
			try {
				Connection co=DriverManager.getConnection(url,username,pwd);
				PreparedStatement pr=co.prepareStatement(deleteq);
				pr.setInt(1,id);
				int result=pr.executeUpdate();
				if(result > 0)
				{
					System.out.println( "deleted");
				}
				co.close();
				pr.close();
			}catch(SQLException e)
			{
				e.printStackTrace();
			}
			System.out.println( "not deleted");
		}

		public String getRecordById(Book obj) 
		{
			try {
				Class.forName("com.mysql.cj.jdbc.Driver");
			}catch(ClassNotFoundException e)
			{
				e.printStackTrace();
			}
			try {
				Connection co=DriverManager.getConnection(url,username,pwd);
				PreparedStatement pr=co.prepareStatement(byid);
				pr.setInt(1, obj.getB_id());
				pr.setString(2,obj.getB_name());
				pr.setInt(3, obj.getB_price());
				int result=pr.executeUpdate();
				if(result>0)
				{
					return "success";
				}
				co.close();
				pr.close();
			}catch(SQLException e) 
			{
				e.printStackTrace();
			}
			return "failed";
			
			
		}
		
		}
			
	






