package com.book.servlet;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.book.dao.BookDao;
import com.book.model.Book;
import com.book.service.BookService;
import com.book.validation.InvalidException;

public class Createservlet extends HttpServlet {
	@Override
	protected void service(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException 
{
		int id=Integer.parseInt(req.getParameter("b_id"));
		String name=req.getParameter("b_name");
		int price=Integer.parseInt(req.getParameter("b_price"));
		
		
	
		Book obj=new Book();
		obj.setB_id(id);
		obj.setB_name(name);
		obj.setB_price(price);
		
		
		BookService obj1=new BookService();
		String c=null;
		c=obj1.createDetails(obj);
		req.setAttribute("create", c);
		req.setAttribute("p1", obj);
		req.getRequestDispatcher("BCreateResponse.jsp").forward(req, resp);

}
}