package com.book.servlet;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


import com.book.dao.BookDao;
import com.book.model.Book;
import com.book.service.BookService;

public class Updateservlet extends HttpServlet {
	@Override
	protected void service(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException 
{
		
		
		int id=Integer.parseInt(req.getParameter("b_id"));
		String name=req.getParameter("b_name");
		int price=Integer.parseInt(req.getParameter("b_price"));
		
		
		//creating object for Employeedetails
		Book obj=new Book();
		obj.setB_id(id);
		obj.setB_name(name);
		obj.setB_price(price);
		
		
		//creating object for Employeeservices
		BookService obj2=new BookService();
		String r=obj2.updateRecord(obj);
		req.setAttribute("update", r);
		
		req.getRequestDispatcher("BUpdateResponse.jsp").forward(req, resp);
}
}