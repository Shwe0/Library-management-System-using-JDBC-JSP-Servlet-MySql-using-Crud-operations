package com.book.servlet;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


import com.book.dao.BookDao;
import com.book.service.BookService;


public class DeleteServlet extends HttpServlet {
	@Override
	protected void service(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException 
{
	int deleteid=Integer.parseInt(req.getParameter("b_id"));
	BookService ds=new BookService();
	ds.deleteBid(deleteid);
	req.setAttribute("delete", deleteid);
	req.getRequestDispatcher("BDeleteResponse.jsp").forward(req, resp);
}
}