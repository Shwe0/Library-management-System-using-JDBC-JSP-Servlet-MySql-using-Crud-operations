package com.book.servlet;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import java.util.List;

import javax.servlet.ServletContext;

import com.book.dao.BookDao;
import com.book.model.Book;
import com.book.model.DatabaseDetails;
import com.book.service.BookService;


@SuppressWarnings("serial")
@WebServlet("/GetByIdServlet")
public class GetByIdServlet extends HttpServlet {
	@Override
	protected void service(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException 
{
		ServletContext ctx=getServletContext();
		String url=ctx.getInitParameter("url");
		String username=ctx.getInitParameter("username");
		String pwd=ctx.getInitParameter("pwd");
		DatabaseDetails gt=new DatabaseDetails(url, username, pwd);
		
		int id=Integer.parseInt(req.getParameter("b_id"));
		BookService b1=new BookService();
		Book res=b1.getRecordById(id, gt);
		req.setAttribute("get", res);
		
		
		req.getRequestDispatcher("getbyidResponse.jsp").forward(req, resp);

		

}
}