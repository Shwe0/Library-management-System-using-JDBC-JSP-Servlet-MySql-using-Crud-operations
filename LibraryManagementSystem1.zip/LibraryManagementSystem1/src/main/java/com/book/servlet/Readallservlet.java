package com.book.servlet;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


import java.util.ArrayList;
import java.util.List;

import com.book.dao.BookDao;
import com.book.model.Book;
import com.book.service.BookService;



@SuppressWarnings("unused")
public class Readallservlet extends HttpServlet {
	@Override
	protected void service(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException 
{
		BookService es=new BookService();
	List<Book> bookdetails=new ArrayList<Book>();
		bookdetails  = es.getBook();
		req.setAttribute("getDetails", bookdetails);
		req.getRequestDispatcher("BReadResponse.jsp").forward(req, resp);
		
}
}